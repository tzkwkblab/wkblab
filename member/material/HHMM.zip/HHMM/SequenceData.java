import java.io.*;
import java.util.*;
public class SequenceData {
	protected ArrayList<Integer[]> data;
	protected int wordNum;
	protected int obsNum;
	
	static public SequenceData loadSequenceSet(String filename) throws Exception{
		return loadSequenceSet(filename, 0);
	}
	
	static public SequenceData loadSequenceSet(String filename, int maxDocNum) throws Exception{
		SequenceData data = new SequenceData();
		HashSet<Integer> wordSet = new HashSet<Integer>();
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(filename)));
		String line = "";
		while((line = br.readLine()) != null){
			String[] strSequence = line.split(" ");
			if( strSequence.length > 0 ){
				Integer[] sequence = new Integer[strSequence.length];
				for(int i=0; i<sequence.length; i++){
					sequence[i] = Integer.valueOf(strSequence[i]);
					wordSet.add(sequence[i]);
				}
				data.data.add(sequence);
				data.obsNum += sequence.length;
				if( maxDocNum > 0 && data.data.size() >= maxDocNum ){
					break;
				}
			}
		}
		br.close();
		data.wordNum = wordSet.size();
		return data;
	}
	
	public SequenceData(){
		data = new ArrayList<Integer[]>();
	}
	
	public SequenceData(Integer[] sequence){
		data = new ArrayList<Integer[]>();
		data.add(sequence);
	}
	
	public Integer[] data(int docID){
		return data.get(docID);
	}
	
	public int docNum(){
		return data.size();
	}
	
	public int wordNum(){
		return wordNum;
	}
	
	public int observationNum(){
		return obsNum;
	}
}
