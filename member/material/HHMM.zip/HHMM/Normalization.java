
public class Normalization {
	static public void normalize(double[] vector){
		normalize(vector, calcSum(vector));
	}
	
	static public void normalize(double[] vector, double sum){
		double div = 1.0 / sum;
		for(int i=0; i<vector.length; i++){
			vector[i] *= div;
		}
	}
	
	static public double[] getNormalized(double[] vector){
		return getNormalized(vector, calcSum(vector));
	}
	
	static public double[] getNormalized(double[] vector, double sum){
		double[] normalized = new double[vector.length];
		double div = 1.0 / sum;
		for(int i=0; i<vector.length; i++){
			normalized[i] = vector[i] * div;
		}
		return normalized;
	}
	
	static public double calcSum(double[] vector){
		double sum = 0.0;
		for(int i=0; i<vector.length; i++){
			sum += vector[i];
		}
		return sum;
	}
}
