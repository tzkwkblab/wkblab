import java.util.*;
import org.apache.commons.math.random.*;
public class FBAS {
	protected static double alpha = 0.01, beta = 0.01, gamma = 0.01;
	protected double[][] pi;
	protected double[][][] A;
	protected double[][] B;
	protected int wordNum;
	protected int stateNum, depth;
	protected int powND;
	protected int[] powNd;
	protected boolean minSR;

	static public FBAS createInstance(int depth, int stateNum, int wordNum, long seed) throws Exception{
		return new FBAS(depth, stateNum, wordNum, seed);
	}
	
	static public FBAS createMinSRInstance(int depth, int stateNum, int wordNum, long seed) throws Exception{
		return new FBAS(depth, stateNum, wordNum, seed, true);
	}
	
	public FBAS(int depth, int stateNum, int wordNum, long seed) throws Exception{
		this(depth, stateNum, wordNum, seed, false);
	}

	public FBAS(int depth, int stateNum, int wordNum, long seed, boolean minSR) throws Exception{
		//initialization
		this.stateNum = stateNum;
		this.depth = depth;
		this.wordNum = wordNum;
		this.minSR = minSR;
		powNd = new int[depth];
		for(int d=0; d<depth; d++){
			powNd[d] = pow(stateNum, d+1);
		}
		powND = powNd[depth-1];
		Random random = new Random(seed);
		double uw = 1.0 / (double)wordNum;
		pi = new double[depth][];
		A = new double[depth][][];
		for(int d=0; d<depth; d++){
			pi[d] = new double[powNd[d]];
			A[d] = new double[powNd[d]][stateNum+1];
			for(int i=0; i<powNd[d]; i++){
				pi[d][i] = random.nextDouble() + 1.0;
				for(int c=0; c<stateNum+1; c++){
					A[d][i][c] = random.nextDouble() + 1.0;
					if( minSR && d < depth-1 && i%stateNum == c ){
						A[d][i][c] = 0.0;
					}
				}
				Normalization.normalize(A[d][i]);
			}
		}
		normalizePi();
		B = new double[powND][wordNum];
		for(int i=0; i<powND; i++){
			for(int w=0; w<wordNum; w++){
				B[i][w] = uw;
			}
		}
	}
	
	private void normalizePi(){
		for(int d=0; d<depth; d++){
			for(int parent=0; parent<powNd[d]/stateNum; parent++){
				int[] zd = new int[stateNum];
				double sumPi = 0.0;
				for(int c=0; c<stateNum; c++){
					zd[c] = parent * stateNum + c;
					sumPi += pi[d][zd[c]];
				}
				for(int c=0; c<stateNum; c++){
					pi[d][zd[c]] /= sumPi;
				}
			}
		}
	}

	public void learn(SequenceData data, int iteration) throws Exception{
		//Activation Forward-Backward Sampling
		MersenneTwister mt = new MersenneTwister();
		long startTime, endTime;
		double[][] piCount;
		double[][][] ACount;
		double[][] BCount;
		piCount = new double[depth][];
		ACount = new double[depth][][];
		BCount = new double[powND][wordNum];
		for(int d=0; d<depth; d++){
			piCount[d] = new double[powNd[d]];
			ACount[d] = new double[powNd[d]][stateNum+1];
		}
		System.out.println("time log-likelihood");
		startTime = System.currentTimeMillis();
		for(int it=0; it<iteration; it++){
			//Gibbs iteration
			double logLikelihood = 0.0;
			//Prior counts
			for(int d=0; d<depth; d++){
				for(int k=0; k<powNd[d]; k++){
					for(int c=0; c<stateNum+1; c++){
						ACount[d][k][c] = alpha;
						if( minSR && d < depth-1 && k%stateNum == c ){
							ACount[d][k][c] = 0.0;
						}
					}
					piCount[d][k] = gamma;
				}
			}
			for(int k=0; k<powND; k++){
				for(int w=0; w<wordNum; w++){
					BCount[k][w] = beta;
				}
			}
			//Sampling
			for(int n=0; n<data.docNum(); n++){
				Integer[] sequence = data.data(n);
				//Forward Calculation
				double[][][] alphaE = new double[sequence.length][depth][];
				double[][][] alphaB = new double[sequence.length][depth][];
				double[] scale = new double[sequence.length+1];
				calAlpha(sequence, alphaE, alphaB, scale);
				//Likelihood
				for(int t=0; t<scale.length; t++){
					logLikelihood += Math.log(scale[t]);
				}
				//Backward Sampling
				int ztd;
				double[] distN = new double[stateNum];
				double[] distNplus1 = new double[stateNum+1];
				for(int i=0; i<stateNum; i++){
					distN[i] = alphaE[sequence.length-1][0][i] * A[0][i][stateNum];
				}
				ztd = select(mt, distN);
				ACount[0][ztd][stateNum]++;
				for(int d=1; d<depth; d++){
					for(int c=0; c<stateNum; c++){
						int i = ztd*stateNum+c;
						distN[c] = alphaE[sequence.length-1][d][i] * A[d][i][stateNum];
					}
					ztd = ztd*stateNum+select(mt, distN);
					ACount[d][ztd][stateNum]++;
				}
				BCount[ztd][sequence[sequence.length-1]]++;
				for(int t=sequence.length-1; t>=1; t--){
					int d = depth-1;
					for(; d>=0; d--){
						if( d > 0 ){
							for(int c=0; c<stateNum; c++){
								int i = (ztd/stateNum)*stateNum + c;
								distNplus1[c] = alphaE[t-1][d][i] * A[d][i][ztd%stateNum];
							}
							distNplus1[stateNum] = alphaB[t][d-1][ztd/stateNum] * pi[d][ztd];
							int select = select(mt, distNplus1);
							if( select == stateNum ){
								//downward vertical transition
								piCount[d][ztd]++;
								ztd = ztd / stateNum;
							}
							else{
								//horizontal transition
								int i = (ztd/stateNum)*stateNum + select;
								ACount[d][i][ztd%stateNum]++;
								ztd = i;
								break;
							}
						}
						else{
							//top hierarchy
							for(int i=0; i<stateNum; i++){
								distN[i] = alphaE[t-1][d][i] * A[d][i][ztd];
							}
							int select = select(mt, distN);
							ACount[d][select][ztd]++;
							ztd = select;
							break;
						}
					}
					for(; d<depth-1; d++){
						//upward vertical transition
						for(int c=0; c<stateNum; c++){
							int i = ztd*stateNum+c;
							distN[c] = alphaE[t-1][d+1][i] * A[d+1][i][stateNum];
						}
						ztd = ztd*stateNum;select(mt, distN);
						ACount[d+1][ztd][stateNum]++;
					}
					BCount[ztd][sequence[t-1]]++;
				}
				for(int d=depth-1; d>=0; d--){
					piCount[d][ztd]++;
					ztd = ztd / stateNum;
				}
			}
			//Parameter Update
			for(int d=0; d<depth; d++){
				pi[d] = Arrays.copyOf(piCount[d], piCount[d].length);
				for(int k=0; k<powNd[d]; k++){
					A[d][k] = Arrays.copyOf(ACount[d][k], ACount[d][k].length);
					Normalization.normalize(A[d][k]);
				}
			}
			normalizePi();
			for(int k=0; k<powND; k++){
				B[k] = Arrays.copyOf(BCount[k], BCount[k].length);
				Normalization.normalize(B[k]);
			}
			endTime = System.currentTimeMillis();
			//Output
			System.out.print((endTime-startTime));
			System.out.println(" "+logLikelihood);
		}
	}

	protected void calAlpha(Integer[] sequence, double[][][] alphaE, double[][][] alphaB, double[] scale){
		//calculating alpha_b at initial time
		scale[0] = 0.0;
		//for d=0
		alphaB[0][0] = new double[powNd[0]];
		for(int b=0; b<powNd[0]; b++){
			alphaB[0][0][b] = pi[0][b];
		}
		//for d>0
		for(int d=1; d<depth; d++){
			alphaB[0][d] = new double[powNd[d]];
			for(int b=0; b<powNd[d]; b++){
				alphaB[0][d][b] = alphaB[0][d-1][b/stateNum] * pi[d][b];
			}
		}
		for(int t=0; t<sequence.length; t++){
			//calculating alpha_e at time t
			//for d=D
			alphaE[t][depth-1] = new double[powNd[depth-1]];
			for(int e=0; e<powNd[depth-1]; e++){
				alphaE[t][depth-1][e] = alphaB[t][depth-1][e] * B[e][sequence[t]];
				scale[t] += alphaE[t][depth-1][e];
			}
			for(int e=0; e<powNd[depth-1]; e++){
				alphaE[t][depth-1][e] /= scale[t];
			}
			//for d<D
			for(int d=depth-2; d>=0; d--){
				alphaE[t][d] = new double[powNd[d]];
				for(int e=0; e<powNd[d]; e++){
					for(int child=0; child<stateNum; child++){
						int echild = e * stateNum + child;
						alphaE[t][d][e] += alphaE[t][d+1][echild] * A[d+1][echild][stateNum];
					}
				}
			}
			//calculating alpha_b at time t+1
			if( t < sequence.length-1 ){
				alphaB[t+1][0] = new double[powNd[0]];
				//for d=0
				for(int b=0; b<powNd[0]; b++){
					for(int e=0; e<powNd[0]; e++){
						alphaB[t+1][0][b] += alphaE[t][0][e] * A[0][e][b];
					}
				}
				//for d>0
				for(int d=1; d<depth; d++){
					alphaB[t+1][d] = new double[powNd[d]];
					for(int b=0; b<powNd[d]; b++){
						int bParent = b / stateNum;
						alphaB[t+1][d][b] = alphaB[t+1][d-1][bParent] * pi[d][b];
						for(int s=0; s<stateNum; s++){
							int e = bParent * stateNum + s;
							alphaB[t+1][d][b] += alphaE[t][d][e] * A[d][e][b%stateNum];
						}
					}
				}
			}
		}
		//scale for alpha_e�@at final time
		int T = sequence.length;
		for(int s=0; s<stateNum; s++){
			scale[T] += alphaE[T-1][0][s] * A[0][s][stateNum];
		}
	}
	
	protected int pow(int a, int b){
		int c = 1;
		for(int i=0; i<b; i++)
			c *= a;
		return c;
	}
	
	private int select(MersenneTwister random, double[] dist){
		double sum = 0.0;
		for(int i=0; i<dist.length; i++){
			sum += dist[i];
		}
		double r = random.nextDouble() * sum;
		sum = 0.0;
		for(int i=0; i<dist.length; i++){
			sum += dist[i];
			if( r <= sum ){
				return i;
			}
		}
		return dist.length-1;
	}
	
	public double[][][] getA(){
		return A;
	}
	
	public double[][] getPi(){
		return pi;
	}
	
	public double[][] getB(){
		return B;
	}
}
