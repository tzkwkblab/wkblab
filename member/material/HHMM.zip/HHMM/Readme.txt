# Forward-Backward Activation Algorithm for Hierarchical Hidden Markov Models

"Main.java" contains a main class that reproduces the experimental results presented in the paper.

You need Apache Commons Math library (http://commons.apache.org/math/) to execute these programs.
