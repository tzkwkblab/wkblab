import java.util.*;

import org.apache.commons.math.random.*;
public class DGS {
	protected static double alpha = 0.01, beta = 0.01, gamma = 0.01;
	protected double[][] pi;
	protected double[][][] A;
	protected double[][] B;
	protected double[][] flatTransProb;
	protected double[] flatInitProb;
	protected double[] flatEndProb;
	protected int wordNum;
	protected int stateNum, depth;
	protected int powND;
	protected int[] powNd;

	static public DGS createInstance(int depth, int stateNum, int wordNum, long seed) throws Exception{
		return new DGS(depth, stateNum, wordNum, seed);
	}

	public DGS(int depth, int stateNum, int wordNum, long seed) throws Exception{
		//initialization
		this.stateNum = stateNum;
		this.depth = depth;
		this.wordNum = wordNum;
		powNd = new int[depth];
		for(int d=0; d<depth; d++){
			powNd[d] = pow(stateNum, d+1);
		}
		powND = powNd[depth-1];
		Random random = new Random(seed);
		double uw = 1.0 / (double)wordNum;
		pi = new double[depth][];
		A = new double[depth][][];
		for(int d=0; d<depth; d++){
			pi[d] = new double[powNd[d]];
			A[d] = new double[powNd[d]][stateNum+1];
			for(int i=0; i<powNd[d]; i++){
				pi[d][i] = random.nextDouble() + 1.0;
				for(int c=0; c<stateNum+1; c++){
					A[d][i][c] = random.nextDouble() + 1.0;
					if( d < depth-1 && i%stateNum == c ){
						A[d][i][c] = 0.0;
					}
				}
				Normalization.normalize(A[d][i]);
			}
		}
		normalizePi();
		B = new double[powND][wordNum];
		for(int i=0; i<powND; i++){
			for(int w=0; w<wordNum; w++){
				B[i][w] = uw;
			}
		}
		flatTransProb = new double[powND][powND];
		flatInitProb = new double[powND];
		flatEndProb = new double[powND];
	}

	private void normalizePi(){
		for(int d=0; d<depth; d++){
			for(int parent=0; parent<powNd[d]/stateNum; parent++){
				int[] zd = new int[stateNum];
				double sumPi = 0.0;
				for(int c=0; c<stateNum; c++){
					zd[c] = parent * stateNum + c;
					sumPi += pi[d][zd[c]];
				}
				for(int c=0; c<stateNum; c++){
					pi[d][zd[c]] /= sumPi;
				}
			}
		}
	}

	public void learn(SequenceData data, int iteration){
		//Direct Gibbs Sampling
		MersenneTwister mt = new MersenneTwister();
		long startTime, endTime, totalTime = 0;
		double[][] piCount = new double[depth][];
		double[][][] ACount = new double[depth][][];
		double[][] BCount = new double[powND][wordNum];
		for(int d=0; d<depth; d++){
			piCount[d] = new double[powNd[d]];
			ACount[d] = new double[powNd[d]][stateNum+1];
		}
		int[][] sample = new int[data.docNum()][];
		for(int n=0; n<data.docNum(); n++){
			sample[n] = new int[data.data(n).length];
			for(int t=0; t<data.data(n).length; t++){
				sample[n][t] = mt.nextInt(powNd[depth-1]);
			}
		}
		System.out.println("time log-likelihood");
		for(int it=0; it<iteration; it++){
			double logLikelihood = 0.0;
			for(int n=0; n<data.docNum(); n++){
				logLikelihood += calcLikelihood(data.data(n));
			}
			//System.out.print(it);
			startTime = System.currentTimeMillis();
			//Calculating flat probabilities
			updateFlatProbability();
			//Prior counts
			for(int d=0; d<depth; d++){
				for(int k=0; k<powNd[d]; k++){
					for(int c=0; c<stateNum+1; c++){
						ACount[d][k][c] = alpha;
						if( d < depth-1 && k%stateNum == c ){
							ACount[d][k][c] = 0.0;
						}
					}
					piCount[d][k] = beta;
				}
			}
			for(int k=0; k<powND; k++){
				for(int w=0; w<wordNum; w++){
					BCount[k][w] = gamma;
				}
			}
			//Sampling
			for(int n=0; n<data.docNum(); n++){
				Integer[] sequence = data.data(n);
				for(int t=0; t<sequence.length; t++){
					double[] dist = new double[powND];
					for(int i=0; i<powND; i++){
						dist[i] = B[i][sequence[t]];
						if( t == 0 ){
							dist[i] *= flatInitProb[i];
						}
						else{
							dist[i] *= flatTransProb[sample[n][t-1]][i];
						}
						if( t == sequence.length-1 ){
							dist[i] *= flatEndProb[i];
						}
						else{
							dist[i] *= flatTransProb[i][sample[n][t+1]];
						}
					}
					sample[n][t] = select(dist, mt);
					BCount[sample[n][t]][sequence[t]]++;
					if( t == 0 ){
						int pai = sample[n][t];
						for(int d=depth-1; d>=0; d--){
							piCount[d][pai]++;
							pai /= stateNum;
						}
					}
					else{
						int sd = siblingDepth(sample[n][t-1], sample[n][t]);
						int pai = sample[n][t];
						int prevPai = sample[n][t-1];
						for(int d=depth-1; d>sd; d--){
							ACount[d][prevPai][stateNum]++;
							piCount[d][pai]++;
							pai /= stateNum;
							prevPai /= stateNum;
						}
						ACount[sd][prevPai][pai%stateNum]++;
					}
					if( t == sequence.length-1 ){
						int pai = sample[n][t];
						for(int d=depth-1; d>=0; d--){
							ACount[d][pai][stateNum]++;
							pai /= stateNum;
						}
					}
				}
			}
			//Parameter Update
			for(int d=0; d<depth; d++){
				pi[d] = Arrays.copyOf(piCount[d], piCount[d].length);
				for(int k=0; k<powNd[d]; k++){
					A[d][k] = Arrays.copyOf(ACount[d][k], ACount[d][k].length);
					Normalization.normalize(A[d][k]);
				}
			}
			normalizePi();
			for(int k=0; k<powND; k++){
				B[k] = Arrays.copyOf(BCount[k], BCount[k].length);
				Normalization.normalize(B[k]);
			}
			endTime = System.currentTimeMillis();
			totalTime += endTime - startTime;
			//Output
			System.out.print(totalTime+" ");
			System.out.println(logLikelihood);
		}
	}
	
	private void updateFlatProbability(){
		for(int i=0; i<powND; i++){
			for(int j=0; j<powND; j++){
				flatTransProb[i][j] = 1.0;
				int sd = siblingDepth(i, j);
				int pai = i;
				int paj = j;
				for(int d=depth-1; d>sd; d--){
					flatTransProb[i][j] *= A[d][pai][stateNum] * pi[d][paj];
					pai /= stateNum;
					paj /= stateNum;
				}
				flatTransProb[i][j] *= A[sd][pai][paj%stateNum];
			}
			int pai = i;
			flatInitProb[i] = 1.0;
			flatEndProb[i] = 1.0;
			for(int d=depth-1; d>=0; d--){
				flatInitProb[i] *= pi[d][pai];
				flatEndProb[i] *= A[d][pai][stateNum];
				pai /= stateNum;
			}
		}
	}
	
	protected double calcLikelihood(Integer[] sequence){
		double logLikelihood = 0.0;
		//Forward Calculation
		double[][][] alphaE = new double[sequence.length][depth][];
		double[][][] alphaB = new double[sequence.length][depth][];
		double[] scale = new double[sequence.length+1];
		calAlpha(sequence, alphaE, alphaB, scale);
		//Likelihood
		for(int t=0; t<scale.length; t++){
			logLikelihood += Math.log(scale[t]);
		}
		return logLikelihood;
	}
	
	protected void calAlpha(Integer[] sequence, double[][][] alphaE, double[][][] alphaB, double[] scale){
		//calculating alpha_b at initial time
		scale[0] = 0.0;
		//for d=0
		alphaB[0][0] = new double[powNd[0]];
		for(int b=0; b<powNd[0]; b++){
			alphaB[0][0][b] = pi[0][b];
		}
		//for d>0
		for(int d=1; d<depth; d++){
			alphaB[0][d] = new double[powNd[d]];
			for(int b=0; b<powNd[d]; b++){
				alphaB[0][d][b] = alphaB[0][d-1][b/stateNum] * pi[d][b];
			}
		}
		for(int t=0; t<sequence.length; t++){
			//calculating alpha_e at time t
			//for d=D
			alphaE[t][depth-1] = new double[powNd[depth-1]];
			for(int e=0; e<powNd[depth-1]; e++){
				alphaE[t][depth-1][e] = alphaB[t][depth-1][e] * B[e][sequence[t]];
				scale[t] += alphaE[t][depth-1][e];
			}
			for(int e=0; e<powNd[depth-1]; e++){
				alphaE[t][depth-1][e] /= scale[t];
			}
			//for d<D
			for(int d=depth-2; d>=0; d--){
				alphaE[t][d] = new double[powNd[d]];
				for(int e=0; e<powNd[d]; e++){
					for(int child=0; child<stateNum; child++){
						int echild = e * stateNum + child;
						alphaE[t][d][e] += alphaE[t][d+1][echild] * A[d+1][echild][stateNum];
					}
				}
			}
			//calculating alpha_b at time t+1
			if( t < sequence.length-1 ){
				alphaB[t+1][0] = new double[powNd[0]];
				//for d=0
				for(int b=0; b<powNd[0]; b++){
					for(int e=0; e<powNd[0]; e++){
						alphaB[t+1][0][b] += alphaE[t][0][e] * A[0][e][b];
					}
				}
				//for d>0
				for(int d=1; d<depth; d++){
					alphaB[t+1][d] = new double[powNd[d]];
					for(int b=0; b<powNd[d]; b++){
						int bParent = b / stateNum;
						alphaB[t+1][d][b] = alphaB[t+1][d-1][bParent] * pi[d][b];
						for(int s=0; s<stateNum; s++){
							int e = bParent * stateNum + s;
							alphaB[t+1][d][b] += alphaE[t][d][e] * A[d][e][b%stateNum];
						}
					}
				}
			}
		}
		//scale for alpha_e�@at final time
		int T = sequence.length;
		for(int s=0; s<stateNum; s++){
			scale[T] += alphaE[T-1][0][s] * A[0][s][stateNum];
		}
	}
	
	protected int pow(int a, int b){
		int c = 1;
		for(int i=0; i<b; i++)
			c *= a;
		return c;
	}

	protected int siblingDepth(int i, int j){
		int pai = i / stateNum;
		int paj = j / stateNum;
		for(int d=depth-1; d>=1; d--){
			if( pai == paj ){
				return d;
			}
			pai /= stateNum;
			paj /= stateNum;
		}
		return 0;
	}
	
	private int select(double[] dist, MersenneTwister mt){
		double sum = 0.0;
		for(int i=0; i<dist.length; i++){
			sum += dist[i];
		}
		double r = mt.nextDouble() * sum;
		sum = 0.0;
		for(int i=0; i<dist.length; i++){
			sum += dist[i];
			if( r <= sum ){
				return i;
			}
		}
		return dist.length-1;
	}
	
	public double[][][] getA(){
		return A;
	}
	
	public double[][] getPi(){
		return pi;
	}
	
	public double[][] getB(){
		return B;
	}
}