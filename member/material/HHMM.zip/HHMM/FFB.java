import java.util.*;
public class FFB {
	protected static double alpha = 0.01, beta = 0.01, gamma = 0.01;
	protected double[][] pi;
	protected double[][][] A;
	protected double[][] B;
	protected double[][] flatTransProb;
	protected double[] flatInitProb;
	protected double[] flatEndProb;
	protected int wordNum;
	protected int stateNum, depth;
	protected int powND;
	protected int[] powNd;

	static public FFB createInstance(int depth, int stateNum, int wordNum, long seed) throws Exception{
		return new FFB(depth, stateNum, wordNum, seed);
	}

	public FFB(int depth, int stateNum, int wordNum, long seed) throws Exception{
		//initialization
		this.stateNum = stateNum;
		this.depth = depth;
		this.wordNum = wordNum;
		powNd = new int[depth];
		for(int d=0; d<depth; d++){
			powNd[d] = pow(stateNum, d+1);
		}
		powND = powNd[depth-1];
		Random random = new Random(seed);
		double uw = 1.0 / (double)wordNum;
		pi = new double[depth][];
		A = new double[depth][][];
		for(int d=0; d<depth; d++){
			pi[d] = new double[powNd[d]];
			A[d] = new double[powNd[d]][stateNum+1];
			for(int i=0; i<powNd[d]; i++){
				pi[d][i] = random.nextDouble() + 1.0;
				for(int c=0; c<stateNum+1; c++){
					A[d][i][c] = random.nextDouble() + 1.0;
					if( d < depth-1 && i%stateNum == c ){
						A[d][i][c] = 0.0;
					}
				}
				Normalization.normalize(A[d][i]);
			}
		}
		normalizePi();
		B = new double[powND][wordNum];
		for(int i=0; i<powND; i++){
			for(int w=0; w<wordNum; w++){
				B[i][w] = uw;
			}
		}
		flatTransProb = new double[powND][powND];
		flatInitProb = new double[powND];
		flatEndProb = new double[powND];
	}

	private void normalizePi(){
		for(int d=0; d<depth; d++){
			for(int parent=0; parent<powNd[d]/stateNum; parent++){
				int[] zd = new int[stateNum];
				double sumPi = 0.0;
				for(int c=0; c<stateNum; c++){
					zd[c] = parent * stateNum + c;
					sumPi += pi[d][zd[c]];
				}
				for(int c=0; c<stateNum; c++){
					pi[d][zd[c]] /= sumPi;
				}
			}
		}
	}

	public void learn(SequenceData data, int iteration){
		//Flattening Forward-Backward algorithm
		long startTime, endTime;
		double[][] piCount = new double[depth][];
		double[][][] ACount = new double[depth][][];
		double[][] BCount = new double[powND][wordNum];
		for(int d=0; d<depth; d++){
			piCount[d] = new double[powNd[d]];
			ACount[d] = new double[powNd[d]][stateNum+1];
		}
		System.out.println("time log-likelihood");
		startTime = System.currentTimeMillis();
		for(int it=0; it<iteration; it++){
			double logLikelihood = 0.0;
			//Calculating flat probabilities
			updateFlatProbability();
			//Prior counts
			for(int d=0; d<depth; d++){
				for(int k=0; k<powNd[d]; k++){
					for(int c=0; c<stateNum+1; c++){
						ACount[d][k][c] = alpha;
						if( d < depth-1 && k%stateNum == c ){
							ACount[d][k][c] = 0.0;
						}
					}
					piCount[d][k] = beta;
				}
			}
			for(int k=0; k<powND; k++){
				for(int w=0; w<wordNum; w++){
					BCount[k][w] = gamma;
				}
			}
			//E-step
			for(int n=0; n<data.docNum(); n++){
				Integer[] sequence = data.data(n);
				double[] scale = new double[sequence.length+1];
				double[][] alpha = new double[sequence.length][powND];
				double[][] beta = new double[sequence.length][powND];
				calAlpha(sequence, alpha, scale);
				calBeta(sequence, beta, scale);
				for(int t=0; t<scale.length; t++){
					logLikelihood += Math.log(scale[t]);
				}
				for(int t=0; t<sequence.length-1; t++){
					for(int i=0; i<powND; i++){
						for(int j=0; j<powND; j++){
							double expect = alpha[t][i] * flatTransProb[i][j] * B[j][sequence[t+1]] *  beta[t+1][j] / scale[t+1];
							int sd = siblingDepth(i, j);
							int pai = i;
							int paj = j;
							for(int d=depth-1; d>sd; d--){
								ACount[d][pai][stateNum] += expect;
								piCount[d][paj] += expect;
								pai /= stateNum;
								paj /= stateNum;
							}
							ACount[sd][pai][paj%stateNum] += expect;
						}
					}
				}
				for(int t=0; t<sequence.length; t++){
					for(int i=0; i<powND; i++){
						double expect = alpha[t][i] * beta[t][i];
						BCount[i][sequence[t]] += expect;
						if( t == 0 ){
							int pai = i;
							for(int d=depth-1; d>=0; d--){
								piCount[d][pai] += expect;
								pai /= stateNum;
							}
						}
						else if( t == sequence.length-1 ){
							int pai = i;
							for(int d=depth-1; d>=0; d--){
								ACount[d][pai][stateNum] += expect;
								pai /= stateNum;
							}
						}
					}
				}
			}
			//M-step
			for(int d=0; d<depth; d++){
				pi[d] = Arrays.copyOf(piCount[d], piCount[d].length);
				for(int k=0; k<powNd[d]; k++){
					A[d][k] = Arrays.copyOf(ACount[d][k], ACount[d][k].length);
					Normalization.normalize(A[d][k]);
				}
			}
			normalizePi();
			for(int k=0; k<powND; k++){
				B[k] = Arrays.copyOf(BCount[k], BCount[k].length);
				Normalization.normalize(B[k]);
			}
			endTime = System.currentTimeMillis();
			//Output
			System.out.print((endTime-startTime));
			System.out.println(" "+logLikelihood);
		}
	}
	
	private void calAlpha(Integer[] sequence, double[][] alpha, double[] scale){
		//Calculating alpha at initial time
		scale[0] = 0.0;
		for(int i=0; i<powND; i++){
			alpha[0][i] = flatInitProb[i] * B[i][sequence[0]];
			scale[0] += alpha[0][i];
		}
		for(int i=0; i<powND; i++){
			alpha[0][i] /= scale[0];
		}
		//Calculating alpha from t=1 to T-1
		for(int t=1; t<sequence.length; t++){
			scale[t] = 0.0;
			for(int j=0; j<powND; j++){
				for(int i=0; i<powND; i++){
					alpha[t][j] += alpha[t-1][i] * flatTransProb[i][j];
				}
				alpha[t][j] *= B[j][sequence[t]];
				scale[t] += alpha[t][j];
			}
			for(int j=0; j<powND; j++){
				alpha[t][j] /= scale[t];
			}
		}
		//scale for final time
		int T = sequence.length;
		for(int i=0; i<powND; i++){
			scale[T] += alpha[T-1][i] * flatEndProb[i];
		}
	}
	
	private void calBeta(Integer[] sequence, double[][] beta, double[] scale){
		//Calculating beta at final time
		for(int i=0; i<powND; i++){
			beta[sequence.length-1][i] = flatEndProb[i] / scale[sequence.length];
		}
		//t=T-2����0�܂ł�beta���v�Z
		for(int t=sequence.length-2; t>=0; t--){
			for(int i=0; i<powND; i++){
				for(int j=0; j<powND; j++){
					beta[t][i] += beta[t+1][j] * flatTransProb[i][j] * B[j][sequence[t+1]];
				}
				beta[t][i] /= scale[t+1];
			}
		}
	}
	
	private void updateFlatProbability(){
		for(int i=0; i<powND; i++){
			for(int j=0; j<powND; j++){
				flatTransProb[i][j] = 1.0;
				int sd = siblingDepth(i, j);
				int pai = i;
				int paj = j;
				for(int d=depth-1; d>sd; d--){
					flatTransProb[i][j] *= A[d][pai][stateNum] * pi[d][paj];
					pai /= stateNum;
					paj /= stateNum;
				}
				flatTransProb[i][j] *= A[sd][pai][paj%stateNum];
			}
			int pai = i;
			flatInitProb[i] = 1.0;
			flatEndProb[i] = 1.0;
			for(int d=depth-1; d>=0; d--){
				flatInitProb[i] *= pi[d][pai];
				flatEndProb[i] *= A[d][pai][stateNum];
				pai /= stateNum;
			}
		}
	}
	
	protected int pow(int a, int b){
		int c = 1;
		for(int i=0; i<b; i++)
			c *= a;
		return c;
	}

	protected int siblingDepth(int i, int j){
		int pai = i / stateNum;
		int paj = j / stateNum;
		for(int d=depth-1; d>=1; d--){
			if( pai == paj ){
				return d;
			}
			pai /= stateNum;
			paj /= stateNum;
		}
		return 0;
	}
	
	public double[][][] getA(){
		return A;
	}
	
	public double[][] getPi(){
		return pi;
	}
	
	public double[][] getB(){
		return B;
	}
}