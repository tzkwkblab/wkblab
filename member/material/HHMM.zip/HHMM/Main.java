public class Main {
	public static void main(String[] args) throws Exception{
		SequenceData data = SequenceData.loadSequenceSet("corpus.txt");
		HHMMLikelihoodExp(data, 3, 3, 0);
		System.out.println("---");
		HHMMLikelihoodExp(data, 3, 4, 0);
		System.out.println("---");
		HHMMLikelihoodExp(data, 4, 3, 0);
		System.out.println("---");
		HHMMLikelihoodExp(data, 4, 4, 0);
	}
	
	private static void HHMMLikelihoodExp(SequenceData data, int depth, int stateNum, int seed) throws Exception{
		//Activation Forward-Backward Algorithm
		System.out.println("Activation Forward-Backward Algorithm for D="+depth+",N="+stateNum);
		learnFBA(data, depth, stateNum, 1000, seed);
		System.out.println("\n");
		//Flattening Method
		System.out.println("Flattening Method for D="+depth+",N="+stateNum);
		learnFFB(data, depth, stateNum, 1000, seed);
		System.out.println("\n");
		//Activation Forward-Backward Sampling Algorithm
		System.out.println("Activation Forward-Backward Sampling Algorithm for D="+depth+",N="+stateNum);
		learnFBAS(data, depth, stateNum, 5000, seed);
		System.out.println("\n");
		//Direct Gibbs Sampling
		System.out.println("Direct Gibbs Sampling for D="+depth+",N="+stateNum);
		learnDGS(data, depth, stateNum, 20000, seed);
		System.out.println();
	}
	
	private static void learnFBA(SequenceData data, int depth, int stateNum, int iteration, int seed) throws Exception{
		FBA afbhhmm = FBA.createInstance(depth, stateNum, data.wordNum(), seed);
		afbhhmm.learn(data, iteration);
	}
	
	private static void learnFFB(SequenceData data, int depth, int stateNum, int iteration, int seed) throws Exception{
		FFB flathhmm = FFB.createInstance(depth, stateNum, data.wordNum(), seed);
		flathhmm.learn(data, iteration);
	}
	
	private static void learnFBAS(SequenceData data, int depth, int stateNum, int iteration, int seed) throws Exception{
		FBAS afbshhmm = FBAS.createInstance(depth, stateNum, data.wordNum(), seed);
		afbshhmm.learn(data, iteration);
	}

	private static void learnDGS(SequenceData data, int depth, int stateNum, int iteration, int seed) throws Exception{
		DGS dgshhmm = DGS.createInstance(depth, stateNum, data.wordNum(), seed);
		dgshhmm.learn(data, iteration);
	}
}
