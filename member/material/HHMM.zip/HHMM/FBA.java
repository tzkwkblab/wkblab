import java.util.*;
public class FBA {
	protected static double alpha = 0.01, beta = 0.01, gamma = 0.01;
	protected double[][] pi;
	protected double[][][] A;
	protected double[][] B;
	protected int wordNum;
	protected int stateNum, depth;
	protected int powND;
	protected int[] powNd;
	protected boolean minSR;

	static public FBA createInstance(int depth, int stateNum, int wordNum, long seed) throws Exception{
		return new FBA(depth, stateNum, wordNum, seed);
	}
	
	static public FBA createMinSRInstance(int depth, int stateNum, int wordNum, long seed) throws Exception{
		return new FBA(depth, stateNum, wordNum, seed, true);
	}
	
	public FBA(int depth, int stateNum, int wordNum, long seed) throws Exception{
		this(depth, stateNum, wordNum, seed, false);
	}

	public FBA(int depth, int stateNum, int wordNum, long seed, boolean minSR) throws Exception{
		//initialization
		this.stateNum = stateNum;
		this.depth = depth;
		this.wordNum = wordNum;
		this.minSR = minSR;
		powNd = new int[depth];
		for(int d=0; d<depth; d++){
			powNd[d] = pow(stateNum, d+1);
		}
		powND = powNd[depth-1];
		Random random = new Random(seed);
		double uw = 1.0 / (double)wordNum;
		pi = new double[depth][];
		A = new double[depth][][];
		for(int d=0; d<depth; d++){
			pi[d] = new double[powNd[d]];
			A[d] = new double[powNd[d]][stateNum+1];
			for(int i=0; i<powNd[d]; i++){
				pi[d][i] = random.nextDouble() + 1.0;
				for(int c=0; c<stateNum+1; c++){
					A[d][i][c] = random.nextDouble() + 1.0;
					if( minSR && d < depth-1 && i%stateNum == c ){
						A[d][i][c] = 0.0;
					}
				}
				Normalization.normalize(A[d][i]);
			}
		}
		normalizePi();
		B = new double[powND][wordNum];
		for(int i=0; i<powND; i++){
			for(int w=0; w<wordNum; w++){
				B[i][w] = uw;
			}
		}
	}
	
	private void normalizePi(){
		for(int d=0; d<depth; d++){
			for(int parent=0; parent<powNd[d]/stateNum; parent++){
				int[] zd = new int[stateNum];
				double sumPi = 0.0;
				for(int c=0; c<stateNum; c++){
					zd[c] = parent * stateNum + c;
					sumPi += pi[d][zd[c]];
				}
				for(int c=0; c<stateNum; c++){
					pi[d][zd[c]] /= sumPi;
				}
			}
		}
	}

	public void learn(SequenceData data, int iteration) throws Exception{
		//Activation Forward-Backward Algorithm
		long startTime, endTime;
		double[][] piCount;
		double[][][] ACount;
		double[][] BCount;
		piCount = new double[depth][];
		ACount = new double[depth][][];
		BCount = new double[powND][wordNum];
		for(int d=0; d<depth; d++){
			piCount[d] = new double[powNd[d]];
			ACount[d] = new double[powNd[d]][stateNum+1];
		}
		System.out.println("time log-likelihood");
		startTime = System.currentTimeMillis();
		for(int it=0; it<iteration; it++){
			//EM iteration
			double logLikelihood = 0.0;
			//Prior counts
			for(int d=0; d<depth; d++){
				for(int k=0; k<powNd[d]; k++){
					for(int c=0; c<stateNum+1; c++){
						ACount[d][k][c] = alpha;
						if( minSR && d < depth-1 && k%stateNum == c ){
							ACount[d][k][c] = 0.0;
						}
					}
					piCount[d][k] = gamma;
				}
			}
			for(int k=0; k<powND; k++){
				for(int w=0; w<wordNum; w++){
					BCount[k][w] = beta;
				}
			}
			//E-step
			for(int n=0; n<data.docNum(); n++){
				Integer[] sequence = data.data(n);
				double[][][] alphaE = new double[sequence.length][depth][];
				double[][][] alphaB = new double[sequence.length][depth][];
				double[][][] betaE = new double[sequence.length][depth][];
				double[][][] betaB = new double[sequence.length][depth][];
				double[] scale = new double[sequence.length+1];
				calAlpha(sequence, alphaE, alphaB, scale);
				calBeta(sequence, betaE, betaB, scale);
				for(int t=0; t<scale.length; t++){
					logLikelihood += Math.log(scale[t]);
				}
				for(int t=0; t<sequence.length-1; t++){
					//Counting A_{dij}
					for(int d=0; d<depth; d++){
						for(int e=0; e<powNd[d]; e++){
							for(int s=0; s<stateNum; s++){
								int b = e / stateNum * stateNum + s;
								ACount[d][e][s] += alphaE[t][d][e] * A[d][e][s] * betaB[t+1][d][b];
							}
						}
					}
				}
				for(int t=0; t<sequence.length; t++){
					//Counting A_{diEnd}
					for(int d=1; d<depth; d++){
						for(int e=0; e<powNd[d]; e++){
							ACount[d][e][stateNum] += alphaE[t][d][e] * A[d][e][stateNum] * betaE[t][d-1][e/stateNum];
						}
					}
					//Counting pi_{di}
					for(int d=1; d<depth; d++){
						for(int b=0; b<powNd[d]; b++){
							piCount[d][b] += alphaB[t][d-1][b/stateNum] * pi[d][b] * betaB[t][d][b];
						}
					}
					//Counting B_{ik}
					for(int Zt=0; Zt<powND; Zt++){
						BCount[Zt][sequence[t]] += alphaE[t][depth-1][Zt] * betaE[t][depth-1][Zt];
					}
				}
				//Counting A_{diEnd} at final time
				for(int e=0; e<powNd[0]; e++){
					ACount[0][e][stateNum] += alphaE[sequence.length-1][0][e] * betaE[sequence.length-1][0][e];
				}
				//Counting pi_{di} at initial time
				for(int b=0; b<powNd[0]; b++){
					piCount[0][b] += alphaB[0][0][b] * betaB[0][0][b];
				}
			}
			//M-step
			for(int d=0; d<depth; d++){
				pi[d] = Arrays.copyOf(piCount[d], piCount[d].length);
				for(int k=0; k<powNd[d]; k++){
					A[d][k] = Arrays.copyOf(ACount[d][k], ACount[d][k].length);
					Normalization.normalize(A[d][k]);
				}
			}
			normalizePi();
			for(int k=0; k<powND; k++){
				B[k] = Arrays.copyOf(BCount[k], BCount[k].length);
				Normalization.normalize(B[k]);
			}
			endTime = System.currentTimeMillis();
			//Output
			System.out.print((endTime-startTime));
			System.out.println(" "+logLikelihood);
		}
	}
	
	protected void calAlpha(Integer[] sequence, double[][][] alphaE, double[][][] alphaB, double[] scale){
		//calculating alpha_b at initial time
		scale[0] = 0.0;
		//for d=0
		alphaB[0][0] = new double[powNd[0]];
		for(int b=0; b<powNd[0]; b++){
			alphaB[0][0][b] = pi[0][b];
		}
		//for d>0
		for(int d=1; d<depth; d++){
			alphaB[0][d] = new double[powNd[d]];
			for(int b=0; b<powNd[d]; b++){
				alphaB[0][d][b] = alphaB[0][d-1][b/stateNum] * pi[d][b];
			}
		}
		for(int t=0; t<sequence.length; t++){
			//calculating alpha_e at time t
			//for d=D
			alphaE[t][depth-1] = new double[powNd[depth-1]];
			for(int e=0; e<powNd[depth-1]; e++){
				alphaE[t][depth-1][e] = alphaB[t][depth-1][e] * B[e][sequence[t]];
				scale[t] += alphaE[t][depth-1][e];
			}
			for(int e=0; e<powNd[depth-1]; e++){
				alphaE[t][depth-1][e] /= scale[t];
			}
			//for d<D
			for(int d=depth-2; d>=0; d--){
				alphaE[t][d] = new double[powNd[d]];
				for(int e=0; e<powNd[d]; e++){
					for(int child=0; child<stateNum; child++){
						int echild = e * stateNum + child;
						alphaE[t][d][e] += alphaE[t][d+1][echild] * A[d+1][echild][stateNum];
					}
				}
			}
			//calculating alpha_b at time t+1
			if( t < sequence.length-1 ){
				alphaB[t+1][0] = new double[powNd[0]];
				//for d=0
				for(int b=0; b<powNd[0]; b++){
					for(int e=0; e<powNd[0]; e++){
						alphaB[t+1][0][b] += alphaE[t][0][e] * A[0][e][b];
					}
				}
				//for d>0
				for(int d=1; d<depth; d++){
					alphaB[t+1][d] = new double[powNd[d]];
					for(int b=0; b<powNd[d]; b++){
						int bParent = b / stateNum;
						alphaB[t+1][d][b] = alphaB[t+1][d-1][bParent] * pi[d][b];
						for(int s=0; s<stateNum; s++){
							int e = bParent * stateNum + s;
							alphaB[t+1][d][b] += alphaE[t][d][e] * A[d][e][b%stateNum];
						}
					}
				}
			}
		}
		//scale for alpha_e�@at final time
		int T = sequence.length;
		for(int s=0; s<stateNum; s++){
			scale[T] += alphaE[T-1][0][s] * A[0][s][stateNum];
		}
	}
	
	protected void calBeta(Integer[] sequence, double[][][] betaE, double[][][] betaB, double[] scale){
		int T = sequence.length;
		//calculating beta_e at final time
		//for d=0
		betaE[T-1][0] = new double[powNd[0]];
		for(int e=0; e<powNd[0]; e++){
			betaE[T-1][0][e] = A[0][e][stateNum] / scale[T];
		}
		//for d>0
		for(int d=1; d<depth; d++){
			betaE[T-1][d] = new double[powNd[d]];
			for(int e=0; e<powNd[d]; e++){
				betaE[T-1][d][e] = betaE[T-1][d-1][e/stateNum] * A[d][e][stateNum];
			}
		}
		for(int t=sequence.length-1; t>=0; t--){
			//calculating beta_b at time t
			//for d=D
			betaB[t][depth-1] = new double[powNd[depth-1]];
			for(int b=0; b<powNd[depth-1]; b++){
				betaB[t][depth-1][b] = betaE[t][depth-1][b] * B[b][sequence[t]] / scale[t];
			}
			//for d<D
			for(int d=depth-2; d>=0; d--){
				betaB[t][d] = new double[powNd[d]];
				for(int b=0; b<powNd[d]; b++){
					for(int child=0; child<stateNum; child++){
						int bchild = b * stateNum + child;
						betaB[t][d][b] += betaB[t][d+1][bchild] * pi[d+1][bchild];
					}
				}
			}
			//calculating beta_e at time t-1
			if( t > 0 ){
				//for d=0
				betaE[t-1][0] = new double[powNd[0]];
				for(int e=0; e<powNd[0]; e++){
					for(int b=0; b<powNd[0]; b++){
						betaE[t-1][0][e] += betaB[t][0][b] * A[0][e][b];
					}
				}
				//for d>0
				for(int d=1; d<depth; d++){
					betaE[t-1][d] = new double[powNd[d]];
					for(int e=0; e<powNd[d]; e++){
						int eParent = e / stateNum;
						betaE[t-1][d][e] = betaE[t-1][d-1][eParent] * A[d][e][stateNum];
						for(int s=0; s<stateNum; s++){
							int b = eParent * stateNum + s;
							betaE[t-1][d][e] += betaB[t][d][b] * A[d][e][s];
						}
					}
				}
			}
		}
	}

	public int[][][] viterbi(SequenceData data){
		int[][] zSequence = new int[data.docNum()][];	//most likely state sequence
		int[][] dSequence = new int[data.docNum()][];	//transition depth
		for(int n=0; n<data.docNum(); n++){
			Integer[] sequence = data.data(n);
			zSequence[n] = new int[sequence.length];
			dSequence[n] = new int[sequence.length];
			double[][] deltaB = new double[depth][];
			double[][] deltaE = new double[depth][];
			int[][][] psiB = new int[sequence.length][depth][];
			int[][][] psiE = new int[sequence.length][depth-1][];
			//calculating delta_b at initial time
			//for d=0
			deltaB[0] = new double[powNd[0]];
			for(int b=0; b<powNd[0]; b++){
				deltaB[0][b] = Math.log(pi[0][b]);
			}
			//for d>0
			for(int d=1; d<depth; d++){
				deltaB[d] = new double[powNd[d]];
				for(int b=0; b<powNd[d]; b++){
					deltaB[d][b] = deltaB[d-1][b/stateNum] + Math.log(pi[d][b]);
				}
			}
			for(int t=0; t<sequence.length; t++){
				//calculating delta_e at time t
				//for d=D
				deltaE[depth-1] = new double[powNd[depth-1]];
				for(int e=0; e<powNd[depth-1]; e++){
					deltaE[depth-1][e] = deltaB[depth-1][e] + Math.log(B[e][sequence[t]]);
				}
				//for d<D
				for(int d=depth-2; d>=0; d--){
					deltaE[d] = new double[powNd[d]];
					psiE[t][d] = new int[powNd[d]];
					for(int e=0; e<powNd[d]; e++){
						double[] probs = new double[stateNum];
						for(int child=0; child<stateNum; child++){
							int echild = e * stateNum + child;
							probs[child] = deltaE[d+1][echild] + Math.log(A[d+1][echild][stateNum]);
						}
						psiE[t][d][e] = argmax(probs);
						deltaE[d][e] = probs[psiE[t][d][e]];
					}
				}
				//calculating delta_b at time t+1
				if( t < sequence.length-1 ){
					deltaB[0] = new double[powNd[0]];
					psiB[t+1][0] = new int[powNd[0]];
					//for d=0
					for(int b=0; b<powNd[0]; b++){
						double[] probs = new double[powNd[0]];
						for(int e=0; e<powNd[0]; e++){
							probs[e] = deltaE[0][e] + Math.log(A[0][e][b]);
						}
						psiB[t+1][0][b] = argmax(probs);
						deltaB[0][b] = probs[psiB[t+1][0][b]];
					}
					//for d>0
					for(int d=1; d<depth; d++){
						deltaB[d] = new double[powNd[d]];
						psiB[t+1][d] = new int[powNd[d]];
						for(int b=0; b<powNd[d]; b++){
							int bParent = b / stateNum;
							double[] probs = new double[stateNum+1];
							probs[stateNum] = deltaB[d-1][bParent] + Math.log(pi[d][b]);
							for(int s=0; s<stateNum; s++){
								int e = bParent * stateNum + s;
								probs[s] = deltaE[d][e] + Math.log(A[d][e][b%stateNum]);
							}
							psiB[t+1][d][b] = argmax(probs);
							deltaB[d][b] = probs[psiB[t+1][d][b]];
						}
					}
				}
			}
			//Termination probability
			int T = sequence.length;
			double[] probs = new double[stateNum];
			for(int s=0; s<stateNum; s++){
				probs[s] = deltaE[0][s] + Math.log(A[0][s][stateNum]);
			}
			//Backtrack
			int psi = argmax(probs);
			for(int d=0; d<depth-1; d++){
				psi = psi * stateNum + psiE[T-1][d][psi];
			}
			zSequence[n][T-1] = psi;
			dSequence[n][T-1] = 0;
			for(int t=sequence.length-2; t>=0; t--){
				for(int d=depth-1; d>=0; d--){
					if( psiB[t+1][d][psi] == stateNum ){
						psi = psi / stateNum;
					}
					else{
						dSequence[n][t] = d;
						psi = psi / stateNum * stateNum + psiB[t+1][d][psi];
						break;
					}
				}
				for(int d=dSequence[n][t]; d<depth-1; d++){
					psi = psi * stateNum + psiE[t][d][psi];
				}
				zSequence[n][t] = psi;
			}
		}
		int[][][] ret = new int[2][][];
		ret[0] = zSequence;
		ret[1] = dSequence;
		return ret;
	}

	private int pow(int a, int b){
		int c = 1;
		for(int i=0; i<b; i++)
			c *= a;
		return c;
	}
	
	private int argmax(double[] probs){
		int argmax = 0;
		double max = probs[0];
		for(int i=1; i<probs.length; i++){
			if( probs[i] > max ){
				max = probs[i];
				argmax = i;
			}
		}
		return argmax;
	}
	
	public double[][][] getA(){
		return A;
	}
	
	public double[][] getPi(){
		return pi;
	}
	
	public double[][] getB(){
		return B;
	}
}
